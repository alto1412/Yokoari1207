﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Count_stage2 : MonoBehaviour {

    public Text cnt;

    // Use this for initialization
    void Start () {
    }

	void Update () {


       // Debug.Log(Stage2Manager.mosu);
        cnt.text = "" + Stage2Manager.mosu;


    }
}
