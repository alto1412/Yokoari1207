﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class kaisu : MonoBehaviour {

    public Text cnt;
    private Text collar;

    // Use this for initialization
    void Start () {
        collar = GetComponent<Text>();
    }
	void Update () {

        cnt.text = "" + Stage2Manager.mosu;


        if (Stage2Manager.mosu == 0)
        {
            collar.color = Color.red;
        }

    }
}
