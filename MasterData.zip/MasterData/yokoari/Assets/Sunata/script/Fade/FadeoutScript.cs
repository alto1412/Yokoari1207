﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FadeoutScript : MonoBehaviour
{
    float alfa;
    float red, green, blue, timec;

    void Start()
    {
        this.enabled = false;

        red = GetComponent<Image>().color.r;
        green = GetComponent<Image>().color.g;
        blue = GetComponent<Image>().color.b;
    }

    void Update()
    {
        GetComponent<Image>().color = new Color(red, green, blue, alfa += Time.deltaTime);

    }
}





