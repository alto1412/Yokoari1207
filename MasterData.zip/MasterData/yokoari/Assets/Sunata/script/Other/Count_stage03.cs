﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Count_stage03 : MonoBehaviour
{

    public Text cnt;
    // Use this for initialization

    void Start()
    {
    }

    void Update()
    {
        cnt.text = "" + Stage3Manager.mosu;
    }
}
