﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TImelimit_umenai : MonoBehaviour
{

    public int Timelimit;
    private Stage2Manager manager;
    private float time;
    public Text scoreLabel;

    public GameObject obj;
    public GameObject obj_TimeOver;
    public bool Gmoverflg = false;
    public bool Gmclear = false;



    void Start()
    {
        
        scoreLabel = GetComponent<Text>();
        manager = GameObject.Find("Manager").GetComponent<Stage2Manager>();

    }


    void Update()
    {

        time += Time.deltaTime;

        scoreLabel.text = "" + (Timelimit - (int)time);

        if ((Timelimit - (int)time) < 0.0f)
        {
            Gmoverflg = true;
            Destroy(obj);
        }

        if(Gmclear == true)
        {
            Destroy(obj);
        }

        if (manager.GMclear == 2)
        {
            Destroy(obj);
        }

    }
}