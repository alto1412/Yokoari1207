﻿using UnityEngine;
using System.Collections;

public class Destroy : MonoBehaviour {


    public GameObject obj;
    public float time;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        Destroy(obj, time);
	}
}
