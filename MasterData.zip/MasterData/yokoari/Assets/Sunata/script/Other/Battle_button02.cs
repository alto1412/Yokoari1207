﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class Battle_button02 : MonoBehaviour
{


    public FadeoutScript fade;
    private float timec;
    private AudioSource music;
    private bool flg = false;


    public void OnMouseDown()
    {
        flg = true;
    }



    void Start()
    {
        fade = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        music = GameObject.Find("GameNoberu").GetComponent<AudioSource>();
        flg = false;
    }

    void Update()
    {

        if (flg == true)
        {
            fade.enabled = true;

            timec += Time.deltaTime;

            music.volume -= (timec * 0.05f);

            if (timec >= 3)
            {
                SceneManager.LoadScene("Ending");
            }
        }

    }
}







