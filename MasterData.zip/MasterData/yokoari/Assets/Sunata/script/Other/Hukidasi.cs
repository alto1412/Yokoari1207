﻿using UnityEngine;
using System.Collections;

public class Hukidasi : MonoBehaviour {

    public SpriteRenderer spriterenderer,spriteChird;
    public SupportcharUp supportcharUp;
    // Use this for initialization

    void Start () {
        spriterenderer = GetComponent<SpriteRenderer>();
        spriteChird = transform.parent.GetComponent<SpriteRenderer>();
        spriterenderer.enabled = false;
        spriteChird.enabled = false;
    }
	
	// Update is called once per frame
	void Update () {

        spriterenderer.enabled = false;
        spriteChird.enabled = false;

        if (supportcharUp.upflg == true)
        {
            spriterenderer.enabled = true;
            spriteChird.enabled = true;
        }



       // spriteChird.enabled = false;
       // Debug.Log("Child is:" + Chird.name);

    }
}
