﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TimeLimit : MonoBehaviour
{

    private int Timelimit = 30;
    private Enemy enemy;
    private float time;
    public Text scoreLabel;

    public GameObject obj;
    public GameObject obj_TimeOver;
    public bool Gmoverflg = false;



    void Start()
    {
        enemy = GameObject.Find("Yokoari_true").GetComponent<Enemy>();
        scoreLabel = GetComponent<Text>();
    }


    void Update()
    {

        time += Time.deltaTime;

        scoreLabel.text = "" + (Timelimit - (int)time);

        if ((Timelimit - (int)time) < 0.0f)
        {
            Gmoverflg = true;
            Destroy(obj);
        }

        if (enemy.clearflg == true)
        {
            Destroy(obj);
        }

    }
}