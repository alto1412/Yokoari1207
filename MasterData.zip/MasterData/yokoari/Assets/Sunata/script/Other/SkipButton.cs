﻿using UnityEngine;
using System.Collections;

public class SkipButton : MonoBehaviour {

    public  bool skipflg = false;

    // Use this for initialization

    public void OnMouseDown() {

        skipflg = true;
    }


    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
