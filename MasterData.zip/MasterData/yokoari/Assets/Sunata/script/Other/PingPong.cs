﻿using UnityEngine;
using System.Collections;

public class PingPong : MonoBehaviour {

    public int posY;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        transform.position = new Vector3(transform.position.x , Mathf.PingPong(Time.time *80, 15) + posY, transform.position.z);
    }
}
