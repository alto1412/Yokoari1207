﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Countdown : MonoBehaviour
{
    [SerializeField]
    private Text _textCountdown;
    [SerializeField]
    private Image _imageMask;
    private AudioSource music;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);


    public GameObject obj;
    public float Posx, Posy;



    void Start()
    {
        music = GameObject.Find("おもちゃ的なサウンドロゴ ").GetComponent<AudioSource>();
        music.enabled = false;
        _textCountdown.text = "";
        StartCoroutine(CountdownCoroutine());
    }

 
    IEnumerator CountdownCoroutine()
    {
        _imageMask.gameObject.SetActive(true);
        _textCountdown.gameObject.SetActive(true);

        _textCountdown.text = " ";
        yield return new WaitForSeconds(0.5f);

        music.enabled = true;

        _textCountdown.text = " 3";
        yield return new WaitForSeconds(1.0f);

        _textCountdown.text = " 2";
        yield return new WaitForSeconds(1.0f);

        _textCountdown.text = " 1";
        yield return new WaitForSeconds(1.0f);

        _textCountdown.text = "GO!";
        yield return new WaitForSeconds(1.0f);

        _textCountdown.text = "";


        Instantiate(obj, new Vector3(Posx, Posy, 0), quat);


        _textCountdown.gameObject.SetActive(false);
        _imageMask.gameObject.SetActive(false);
    }
}

