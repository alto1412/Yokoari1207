﻿using UnityEngine;
using System.Collections;

public class SupportcharUp : MonoBehaviour {

    public Supportchar suportchar;
    private BoxCollider2D Act;
    private float time,time2,time3;
    public bool upflg = false;

	// Use this for initialization
	void Start () {
        Act = this.GetComponent<BoxCollider2D>();
        suportchar = this.GetComponent<Supportchar>();
	}
	
	// Update is called once per frame
	void Update () {

        /*  transform.position = new Vector3(transform.position.x, Mathf.PingPong(Time.time, 10), transform.position.z);*/

      if (suportchar.flg == false){

          time += Time.deltaTime;
          transform.Translate(0, time, 0);
          suportchar.underFlg = false;


          if(time >= 0.5){

             suportchar.flg = true;
             upflg = true;
             time = 0;
          }

      }

          if (upflg == true){

              Act.enabled = false;
              time2 += Time.deltaTime;
              time3 += Time.deltaTime;
             
             if (time2 >= 2.0f){

                 transform.Translate(0, time3 * -0.1f, 0);

                 if (time3 >= 2.564f){

                     upflg = false;
                     Act.enabled =true;
                     time3 = 0;
                     time2 = 0;

                  }
              }
          }
    }
 }
