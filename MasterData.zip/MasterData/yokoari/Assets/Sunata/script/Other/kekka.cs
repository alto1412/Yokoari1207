﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class kekka : MonoBehaviour {


    private Image stamp02,stamp03,stamp04;
    private Text tcolor;
    

    // Use this for initialization
    void Start () {

        stamp02 = GameObject.Find("Stamp02").GetComponent<Image>();
        stamp03 = GameObject.Find("Stamp03").GetComponent<Image>();
        stamp04 = GameObject.Find("Stamp04").GetComponent<Image>();
        tcolor = GameObject.Find("miss").GetComponent<Text>();
        tcolor.color = Color.blue;

        stamp02.enabled = false;
        stamp03.enabled = false;
        stamp04.enabled = false;

    }
	
	// Update is called once per frame
	void Update () {


           if (Stage2Manager.mosu == 0)
            {
                tcolor.color= Color.red;
                stamp02.enabled = true;
                stamp03.enabled = false;
                stamp04.enabled = false;
            }

              else  if (Stage2Manager.mosu <= 5 && Stage2Manager.mosu >= 1)
              {
                  tcolor.color = Color.blue;
                  stamp02.enabled = false;
                  stamp03.enabled = true;
                  stamp04.enabled = false;
              }

                else {
                    tcolor.color = Color.blue;
                    stamp02.enabled = false;
                    stamp03.enabled = false; ;
                    stamp04.enabled = true;
            
                 }
    }
  }

