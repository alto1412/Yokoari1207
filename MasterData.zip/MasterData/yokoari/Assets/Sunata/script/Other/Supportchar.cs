﻿using UnityEngine;
using System.Collections;

public class Supportchar : MonoBehaviour {

    private float pos, time ;
    public bool flg = true, underFlg = true;
    private SpriteRenderer obj,obj2,obj3;

    void Start()
    {
        underFlg = true;
        obj = GameObject.Find("Understand").GetComponent<SpriteRenderer>();
        //obj = GameObject.Find("Understand").GetComponentInParent<SpriteRenderer>();
        obj2 = GameObject.Find("supportchar02").GetComponent<SpriteRenderer>();
        obj3 = GameObject.Find("supportchar01").GetComponent<SpriteRenderer>();
    }

    public void OnMouseDown()
    {
        flg = false;
        underFlg = false;
        time = 0;

    }


    void Update()
    {
        time += Time.deltaTime;

        if (underFlg == false)
        {
            obj.enabled = false;
            obj2.enabled = false;
            obj3.enabled = false;
        }


        if(underFlg == true)
        {

            obj.enabled = true;
            obj2.enabled = true;
            obj3.enabled = true;

        }

        if(time >= 5.0f)
        {
            underFlg = true;
            time = 0;
        }

    }











}