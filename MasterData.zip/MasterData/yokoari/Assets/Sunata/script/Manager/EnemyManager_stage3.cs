﻿using UnityEngine;
using System.Collections;

public class EnemyManager_stage3 : MonoBehaviour {
    private float[] Target1 = new float[] {   -3.98f , -0.79f,
                                             -3.69f , -1.27f,
                                               5.14f , -0.35f,
                                              9.89f , 0.85f,
                                              -0.07f , -3.37f};

    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private int ran;
    public GameObject obj;



    // Use this for initialization
    void Start()
    {
        ran = Random.Range(1, 6);

        switch (ran)
        {

            case 1:
                Instantiate(obj, new Vector3(Target1[0], Target1[1], 0), quat);
                break;
            case 2:
                Instantiate(obj, new Vector3(Target1[2], Target1[3], 0), quat);
                break;
            case 3:
                Instantiate(obj, new Vector3(Target1[4], Target1[5], 0), quat);
                break;
            case 4:
                Instantiate(obj, new Vector3(Target1[6], Target1[7], 0), quat);
                break;
            case 5:
                Instantiate(obj, new Vector3(Target1[8], Target1[9], 0), quat);
                break;

            default:
                Debug.Log("Error Error");
                break;

        }

    }
}
