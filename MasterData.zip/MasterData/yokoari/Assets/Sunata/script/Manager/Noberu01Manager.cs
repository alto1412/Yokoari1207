﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Noberu01Manager : MonoBehaviour {


    private Textcontroller text;
    private bool Occurrence = false;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private float timec;
    private FadeoutScript fade;
    private SkipButton skip;
    private AudioSource music;
    public GameObject Normal_obj,Bord_obj;

	// Use this for initialization
	void Start () {
        Occurrence = false;
        text = GameObject.Find("Textcontroler").GetComponent<Textcontroller>();
        fade = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        skip = GameObject.Find("Skip").GetComponent<SkipButton>();
        music = GameObject.Find("GameNoberu").GetComponent<AudioSource>();

    }
	
	// Update is called once per frame
	void Update () {
	
      if(  text.currentLine == 5)
        {
            Destroy(Normal_obj);
    
            if(Occurrence == false)
              {
                 Instantiate(Bord_obj, new Vector3(transform.position.x, transform.position.y, transform.position.z), quat);
                 Occurrence = true;
              }   
        }

      if(text.currentLine == 8)
        {
            fade.enabled = true;
            timec += Time.deltaTime;
            music.volume -= (timec * 0.05f);

            if (timec >= 2)
            {
                SceneManager.LoadScene("Tutorial");
            }

        }

      if(skip.skipflg == true)
        {

            fade.enabled = true;
            timec += Time.deltaTime;
            music.volume -= (timec * 0.05f);

            if (timec >= 2)
            {
                SceneManager.LoadScene("Noberu02");
            }

        }
	}
}
