﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class LastManager : MonoBehaviour {


    private float timec;
    private bool limitflg = false;
    private FadeoutScript fade;
    private AudioSource music;

    public void OnMouseDown()
    {

        limitflg = true;

    }

    // Use this for initialization
    void Start () {

        fade = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        music = GameObject.Find("GameLast ").GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
	

        if(limitflg == true)
        {
           
            timec += Time.deltaTime;
            music.volume -= (timec  *  0.01f);


            if (timec >= 2)
            {
                fade.enabled = true;
            }
            if (timec >= 4)
            {
                SceneManager.LoadScene("Title");
            }
        }
	}
}
