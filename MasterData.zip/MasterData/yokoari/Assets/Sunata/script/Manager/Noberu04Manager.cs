﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class Noberu04Manager : MonoBehaviour {


    private Textcontroller text;
    private FadeoutScript fade;
    private float timec;
    private AudioSource music;
    private Transform obj;


    // Use this for initialization
    void Start () {

        text = GameObject.Find("Textcontroler").GetComponent<Textcontroller>();
        fade = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        music = GameObject.Find("GameNoberu").GetComponent<AudioSource>();
        obj = GameObject.Find("Yokoari_normal").GetComponent<Transform>();
    }
	
	// Update is called once per frame
	void Update () {
        if(text.currentLine == 2)
        {
            obj.transform.localScale = new Vector3(0.5f, 0.5f, 1f);
            obj.transform.localPosition = new Vector3(0.2f, 0.8f, 1f);

        }
        
        if (text.currentLine == 7)
        {
            fade.enabled = true;

            timec += Time.deltaTime;

            music.volume -= (timec * 0.05f);

            if (timec >= 3)
            {
                SceneManager.LoadScene("Stage03");
            }

        }


    }
}
