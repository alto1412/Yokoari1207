﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class TitleManager : MonoBehaviour
{

    private FadeoutScript fadeout;
    private float timec;
    private AudioSource music;


    // Use this for initialization
    void Start()
    {
        fadeout = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        music = GameObject.Find("GameTitle").GetComponent<AudioSource>();
    }

  
    // Update is called once per frame
    void Update()
    {

        if (Input.GetMouseButton(0))
        {
            fadeout.enabled = true;
        }



        if(fadeout.enabled == true)
        {
            timec += Time.deltaTime;
            music.volume -= (timec * 0.1f);

            if (timec >= 2.5f)
            {
                SceneManager.LoadScene("Noberu01");
            }

        }
    }

    

}

