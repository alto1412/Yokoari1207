﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class Manager : MonoBehaviour
{

    public GameObject obj_TimeOver,obj;

    private bool GMclear = false;
    private FadeoutScript fade;
    private Enemy enemy;
    private TimeLimit time;
    private Supportchar Schar;
    private float timec;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private AudioSource music;




    // Use this for initialization
    void Start()
    {
        fade  =  GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        enemy =  GameObject.Find("Yokoari_true").GetComponent<Enemy>();
        time  =  GameObject.Find("Time").GetComponent<TimeLimit>();
        music =  GameObject.Find("Gametutorial").GetComponent<AudioSource>();
        Schar =  GameObject.Find("Yokoari_normal").GetComponent<Supportchar>();
    }





    // Update is called once per frame
    void Update()
    {
        if(enemy.clearflg == true)
        {
            GMclear = true;
        }


        if(GMclear == true)
        {

            timec += Time.deltaTime;
            music.volume -= (timec * 0.001f);
            Schar.underFlg = false;


            if (timec >= 3.0)
            {
                fade.enabled = true;
                

                if (timec >= 7)
                

                    SceneManager.LoadScene("Noberu02");

            }
        }


        if(time.Gmoverflg == true)
        {
            timec += Time.deltaTime;
            Schar.underFlg = false;


            if (timec >= 0.1f  &&  timec <= 0.15f)
            {
                Instantiate(obj_TimeOver, new Vector3(2.7f, 6.5f, transform.position.z), quat);
            }


            enemy.overflg = true;
            

            if (timec >= 3)
            {

                fade.enabled = true;
                music.volume -= (timec * 0.05f);


                if (timec >= 7)
                {
                    SceneManager.LoadScene("Noberu02_false");
                }

            }
        }

    }
}