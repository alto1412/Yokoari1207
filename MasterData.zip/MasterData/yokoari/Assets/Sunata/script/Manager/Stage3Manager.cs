﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class Stage3Manager : MonoBehaviour
{

    public GameObject obj_TimeOver;
    public int GMclear = 0;
    public static int mosu;
    public static int sosu;
    public AudioClip audio1;
    public bool musicflg = false;
    public FadeoutScript fade1;


    public  FadeoutScript fade;
    private Enemy_stage3 enemy;
    private Timelimit_stage3 time;
    private Canvas canvas;
    private float timec;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private AudioSource music, result, over;
    private AudioSource audiosource;



    // Use this for initialization
    void Start()
    {

       
        time = GameObject.Find("Time").GetComponent<Timelimit_stage3>();
        canvas = GameObject.Find("Canvas").GetComponent<Canvas>();
        music = GameObject.Find("GameMain").GetComponent<AudioSource>();
        result = GameObject.Find("Resultmusic").GetComponent<AudioSource>();
        over = GameObject.Find("GameOver").GetComponent<AudioSource>();

        audiosource = gameObject.GetComponent<AudioSource>();
        audiosource.clip = audio1;

        over.enabled = false;
        canvas.enabled = false;
        result.enabled = false;
        GMclear = 0;
        mosu = 0;

    }

    // Update is called once per frame
    void Update()
    {


        enemy = GameObject.Find("Yokoari_Nomal(Clone)").GetComponent<Enemy_stage3>();

        if (GMclear == 1)
        {

            timec += Time.deltaTime;
            music.volume -= (timec * 0.01f);

            if (timec >= 3)
            {
                canvas.enabled = true;
                result.enabled = true;
            }


            if (timec >= 7)
            {
                fade.enabled = true;

                if (timec >= 8)
                {
                    SceneManager.LoadScene("LastEnding");
                }

            }
        }



        if (time.Gmoverflg == true)
        {
           
            over.enabled = true;
            timec += Time.deltaTime;
          
            music.volume -= (timec * 0.05f);

            if (timec >= 0.1f && timec <= 0.15f)
            {
                Instantiate(obj_TimeOver, new Vector3(2.7f, 6.5f, transform.position.z), quat);
            }

            

            enemy.overflg = true;


            if (timec >= 5)
            {

                fade1.enabled = true;


                if (timec >= 7)
                {
                    SceneManager.LoadScene("LoseEnding");
                }

            }
        }

        if (musicflg == true)
        {
            audiosource.Play();
            musicflg = false;
        }

    }
}

