﻿using UnityEngine;
using System.Collections;

public class Noberu03Manager : MonoBehaviour {

    public GameObject obj;

    private Textcontroller text;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private Canvas canvas;
    private SpriteRenderer ykoari;
    public bool NM3flg = false;
    private int cnt;
    

	// Use this for initialization
	void Start () {
        
        text = GameObject.Find("Textcontroler").GetComponent<Textcontroller>();
        canvas = GameObject.Find("Canvas").GetComponent<Canvas>();
        ykoari = GameObject.Find("Yokoari_normal").GetComponent<SpriteRenderer>();
        canvas.enabled = true;
        ykoari.enabled = true;
        cnt = 0;
        NM3flg = false;
    }
	
	// Update is called once per frame
	void Update () {
        

        if (text.currentLine == 3) 
        {
            ykoari.enabled = false;
            canvas.enabled = false;
            cnt++;
            NM3flg = true;
        }

        if(cnt>= 100)
        {
            cnt = 2;
        }


        if (NM3flg = true && cnt == 1) {
            Instantiate(obj, new Vector3(transform.position.x + 0.3f, transform.position.y, transform.position.z), quat);
            NM3flg = false;
        }


    }
}
