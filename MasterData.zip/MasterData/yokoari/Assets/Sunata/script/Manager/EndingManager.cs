﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class EndingManager : MonoBehaviour {

    private Textcontroller text;
    private FadeoutScript fade;
    private AudioSource music;
    private float timec;
    public int lastline;

	// Use this for initialization
	void Start () {

        text = GameObject.Find("Textcontroler").GetComponent<Textcontroller>();
        fade = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        music = GameObject.Find("GameNoberu").GetComponent<AudioSource>();

    }
	
	// Update is called once per frame
	void Update () {
	
        if(text.currentLine == lastline)
        {
           
            fade.enabled = true;
            timec += Time.deltaTime;
            music.volume -= (timec * 0.05f);

            if (timec >= 2)
            {
                SceneManager.LoadScene("Last");
            }

           
        }



    }
}
