﻿using UnityEngine;
using System.Collections;

public class EnemyManager : MonoBehaviour {

    private float[] Target1 = new float[] {  -3.00f, -3.75f,
                                             14.00f, -3.13f,
                                              2.92f, -2.97f,
                                              8.77f, -3.27f,
                                             14.28f,-4.85f };

    private float[] Target2 = new float[] {  -2.41f, -1.77f,
                                              6.03f, -1.77f,
                                             10.91f, -1.77f,
                                              5.00f, -1.42f,
                                             -0.44f, -1.42f };


    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private int ran,ran2;
    public GameObject obj,obj2;
    

    // Use this for initialization
    void Start () {

        ran = Random.Range(1, 6);
        ran2 = Random.Range(1, 6);


        switch (ran)
        {

            case 1:
                    Instantiate(obj, new Vector3(Target1[0], Target1[1],0), quat);
                     break;
            case 2:
                    Instantiate(obj, new Vector3(Target1[2], Target1[3], 0), quat);
                    break;
            case 3:
                    Instantiate(obj, new Vector3(Target1[4], Target1[5], 0), quat); 
                    break;
            case 4:
                    Instantiate(obj, new Vector3(Target1[6], Target1[7], 0), quat);
                    break;
            case 5:
                    Instantiate(obj, new Vector3(Target1[8], Target1[9], 0), quat);
                    break;
            default:
                    Debug.Log("Error Error");
                    break;

        }


        switch (ran2)
        {

            case 1:
                Instantiate(obj2, new Vector3(Target2[0], Target2[1], 0), quat);
                break;
            case 2:
                Instantiate(obj2, new Vector3(Target2[2], Target2[3], 0), quat);
                break;
            case 3:
                Instantiate(obj2, new Vector3(Target2[4], Target2[5], 0), quat);
                break;
            case 4:
                Instantiate(obj2, new Vector3(Target2[6], Target2[7], 0), quat);
                break;
            case 5:
                Instantiate(obj2, new Vector3(Target2[8], Target2[9], 0), quat);
                break;

            default:
                Debug.Log("Error Error");
                break;

        }

    }

}
