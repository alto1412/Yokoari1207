﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Noberu02Manager : MonoBehaviour
{

    private Textcontroller text;
    private float timec;
    private FadeoutScript fade;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private AudioSource music;
    private bool flg = false;
    public GameObject obj,obj2;

    // Use this for initialization
    void Start()
    {
       flg =  false;
        text = GameObject.Find("Textcontroler").GetComponent<Textcontroller>();
        fade = GameObject.Find("Fadeout").GetComponent<FadeoutScript>();
        music = GameObject.Find("GameNoberu").GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        if(text.currentLine == 2)
        {

            if (flg == false)
            {

                Destroy(obj);
                Instantiate(obj2, new Vector3(transform.position.x, transform.position.y, transform.position.z), quat);
                flg = true;
            }

        }


        if (text.currentLine == 4)
        {
            fade.enabled = true;

            timec += Time.deltaTime;

            music.volume -= (timec * 0.05f);

            if (timec >= 3)
            {
                SceneManager.LoadScene("Stage2");
            }

        }
    }
}

