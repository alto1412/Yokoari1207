﻿using UnityEngine;
using System.Collections;

public class Enemy2_stage2 : MonoBehaviour
{

    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private BoxCollider2D coll;
    private Stage2Manager manager;


    public static bool hitflg = false;
    public GameObject obj;


    public void Start()
    {

        manager = GameObject.Find("Manager").GetComponent<Stage2Manager>();
        coll = GetComponent<BoxCollider2D>();
        coll.enabled = true;
        hitflg = false;
    }


    public void OnMouseDown()
    {

        
        manager.musicflg = true;
        Stage2Manager.mosu++;
        

        if (manager.GMclear != 2)
        {
            Instantiate(obj, new Vector3(transform.position.x, transform.position.y - 0.8f, transform.position.z), quat);
        }

       
    }

     void Update()
    {

        if(manager.GMclear == 2)
        {
            hitflg = true;
        }

        if (hitflg == true)
        {

            coll.enabled = false;

        }

    }

}


