﻿using UnityEngine;
using System.Collections;

public class Enemy2 : MonoBehaviour {



    public GameObject obj;
    public AudioClip audio1;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private Enemy enemy;
    private AudioSource audiosource;

    public void Start()
    {
        enemy = GameObject.Find("Yokoari_true").GetComponent<Enemy>();
        audiosource = gameObject.GetComponent<AudioSource>();
        audiosource.clip = audio1;
    }

    public void OnMouseDown()
    {

   
        audiosource.Play();


        if (enemy.clearflg == false)
        {
            Instantiate(obj, new Vector3(transform.position.x , transform.position.y, transform.position.z), quat);
        }

    }
}
