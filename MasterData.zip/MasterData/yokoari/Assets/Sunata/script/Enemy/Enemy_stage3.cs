﻿using UnityEngine;
using System.Collections;

public class Enemy_stage3 : MonoBehaviour
{



    public GameObject obj, obj2, obj3;
    public bool clearflg = false, overflg = false;
    public AudioClip audio1;

    private float timeC;
    private Quaternion quat = Quaternion.Euler(0, 0, 0);
    private BoxCollider2D collideR;
    private Canvas canvas;
    private Object o;
    private Stage3Manager manager;
    private AudioSource audiosource;





    // Use this for initialization
    void Start()
    {

        collideR = GetComponent<BoxCollider2D>();
        manager = GameObject.Find("Manager").GetComponent<Stage3Manager>();
        canvas = GameObject.Find("Canvas").GetComponent<Canvas>();
        audiosource = gameObject.GetComponent<AudioSource>();
        audiosource.clip = audio1;
    }

    public void OnMouseDown()
    {

        audiosource.Play();
        o = Instantiate(obj, new Vector3(transform.position.x, transform.position.y, transform.position.z), quat);



        collideR.enabled = false;

        manager.GMclear += 1;



        if (manager.GMclear == 1)
        {
            Instantiate(obj2, new Vector3(0.1f, 0.0f, 0), quat);

        }



    }


    void Update()
    {



        if (clearflg == true)
        {

            transform.localScale = new Vector3(1 + timeC, 1 + timeC, 0);

            timeC += Time.deltaTime * 0.4f;

            if (timeC >= 0.2f)
            {
                timeC = 0.2f;
            }

        }


        if (overflg == true)
        {
            //transform.localScale = new Vector3(1 + timeC, 1 + timeC, 0);

            timeC += Time.deltaTime;
            collideR.enabled = false;

            if (timeC >= 0.01f && timeC <= 0.05f)
            {
                Instantiate(obj3, new Vector3(transform.position.x, transform.position.y, transform.position.z), quat);
            }

        }

        if (canvas.enabled == true)
        {
            Destroy(o);
        }



    }
}
